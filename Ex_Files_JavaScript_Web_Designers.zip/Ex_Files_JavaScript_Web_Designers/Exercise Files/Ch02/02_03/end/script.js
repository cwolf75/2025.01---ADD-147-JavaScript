(function() {
"use strict";

var variable1 = 2, variable2 = "Hello";

console.log("Variable 1, and variable 2", variable1, variable2);
console.error("Variable 2", variable2);

})();