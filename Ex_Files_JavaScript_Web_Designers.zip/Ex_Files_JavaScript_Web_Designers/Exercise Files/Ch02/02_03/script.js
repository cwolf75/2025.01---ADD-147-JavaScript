(function() {
"use strict";

// Your code goes here.

})();