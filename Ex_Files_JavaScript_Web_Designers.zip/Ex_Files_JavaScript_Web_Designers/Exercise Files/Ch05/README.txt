This chapter uses the Bing Maps API, which requires a key.

In order to follow the examples, you must get your own key and insert it into the index.html files where you see "YOUR_API_KEY".  If you don't do this, the examples *will not work*.

To get your API key, start here: https://www.bingmapsportal.com/