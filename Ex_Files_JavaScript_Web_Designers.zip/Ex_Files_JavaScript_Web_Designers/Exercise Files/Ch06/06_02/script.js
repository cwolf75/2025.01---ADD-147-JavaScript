(function() {
  "use strict";

  document.addEventListener("DOMContentLoaded", function() {
    var zipField = document.getElementById("billing_postcode"),
      cityField = document.getElementById("billing_city"),
      stateField = document.getElementById("billing_state");

    // Go from here
  });
})();
